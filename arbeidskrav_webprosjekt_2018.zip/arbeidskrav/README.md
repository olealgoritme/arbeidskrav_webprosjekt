# arbeidskrav_webprosjekt 

ARBEIDSKRAV FOR WEBPROSJEKT -- OKTOBER 2018
--------------------------------------------
Frontend- og mobilutvikling, Kristiania Høyskole
laget av Ole Algoritme, Kjetil Haug Terjesen, Mattis Pandur Nordlien

URL webside: https://ole.netbyte.no
URL github: https://github.com/olealgoritme/arbeidskrav_webprosjekt